package Monster;


public class Monster {
    
    public String monsterName;
    public int monsterMaxLife;
    public int monsterLife;
    public int monsterAttack;
    public int monsterDefense;
}
