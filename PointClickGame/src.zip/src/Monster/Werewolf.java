package Monster;


public class Werewolf extends Monster{
    
    public Werewolf(){
        monsterName = "Werewolf";
        monsterMaxLife = 5;
        monsterLife = 5;
        monsterAttack = 5; // 0-4 arası
        monsterDefense = 1;
    }
    
}
